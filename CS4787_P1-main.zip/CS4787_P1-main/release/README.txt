The project instructions are hosted on the web at:

http://www.cs.cornell.edu/courses/cs4787/2022fa/projects/pa1/

Setup instructions: to install the required python packages, run

pip3 install -r requirements.txt
